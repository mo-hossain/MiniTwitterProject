/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import business.Follow;
import business.Hashtag;
import business.Twit;
import business.User;
import business.twitHashtag;
import dataaccess.FollowDB;
import dataaccess.HashtagDB;
import dataaccess.TwitDB;
import dataaccess.UserDB;
import dataaccess.twitHashtagDB;
import email.Email;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.mail.MessagingException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.Cookie;

@WebServlet(name = "membershipServlet", urlPatterns = {"/membership"})
public class membershipServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        //get the actions
        String action = request.getParameter("action");
        String url = "/home.jsp";
        
        if(action.equals("Home")){
            //deletes current session
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute("user");
            
            //set users and twits attributes here
            ArrayList<Twit> twits = TwitDB.searchAll(user);
            session.setAttribute("twits", twits);

            ArrayList<User> users = UserDB.searchALL(user.getEmail());
            session.setAttribute("users", users);
            
            url = "/home.jsp";
        }
        
        else if(action.equals("Notifications")){
            url = "/notifications.jsp";
                
            HttpSession session = request.getSession();
                
            //create user
            User user = null;
            user = (User) session.getAttribute("user");
            
            //check if session is active
            if(user == null){
                request.setAttribute("errorMessage", "Unexpected error occured");
                url = "/login.jsp";
            }
            String dateCheck = user.getLastLogin();
            SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            
            ArrayList<Twit> twits = null;
            twits = (ArrayList<Twit>) session.getAttribute("twits");
            
            for(int i = 0; i < twits.size(); i++){
                String getTwitDate = twits.get(i).getTwitDate();
                try {
                    Date lastLogin = format.parse(dateCheck);
                    Date twitDate = format.parse(getTwitDate);
                    
                        if(twitDate.compareTo(lastLogin) < 0){
                        twits.remove(i);
                        i--;
                    }
                } catch (ParseException ex) {
                    Logger.getLogger(membershipServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
            //check if session is active
            if(twits == null){
                request.setAttribute("errorMessage", "Unexpected error occured");
                url = "/login.jsp";
            }
            
            //set users and twits attributes here
            session.setAttribute("twits", twits);
        }
        
        else if(action.equals("Hashtag")){
            url = "/hashtag.jsp";
        }
        
        else if(action.equals("SignOut")){
            //deletes current session
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute("user");
            
            String lastLogin = "";
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            lastLogin = dtf.format(now);
            
            user.setLastLogin(lastLogin);
            UserDB.update(user);
            
            session.invalidate();
            
            Cookie[] cookies = request.getCookies();
            for(Cookie cookie: cookies)
            {
                cookie.setMaxAge(0);
                cookie.setPath("/");
                response.addCookie(cookie);
            }
            
            url = "/login.jsp";
        }
        
        //set current date
        Date currentDate = new Date();
        request.setAttribute("currentDate", currentDate);
        
        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, 
                          HttpServletResponse response)
                          throws ServletException, IOException {
        //set current url page
        String url = "signup.jsp";
        
        //get current action
        String action = request.getParameter("action");
        
        if(action.equals("signup")){
            //To print out text from here
            response.setContentType("text/html");
            response.setCharacterEncoding("UTF-8");
            
            // get parameters from the request
            String fullName = request.getParameter("fullName");
            String userName = request.getParameter("userName");
            String email = request.getParameter("email"); 
            String password = request.getParameter("password");
            String confirmPassword = request.getParameter("confirmpassword");
            String birthday = request.getParameter("birthday");
            String questionNo = request.getParameter("questionNo");
            String answer = request.getParameter("answer");
            String profilePic = "Test";
            String userSalt = UserDB.randomString(8);
            
            String hashAndSaltPass = null;
            try {
                hashAndSaltPass = UserDB.hashAndSaltPassword(userSalt, password);
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(membershipServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            String lastLogin = "";
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            lastLogin = dtf.format(now);
                    
            // store data in User object
            User user = new User();
            user.setFullName(fullName);
            user.setUserName(userName);
            user.setEmail(email);
            user.setPassword(hashAndSaltPass);
            user.setBirthday(birthday);
            user.setQuestionNO(questionNo);
            user.setAnswer(answer);            
            user.setProfilePic(profilePic);
            user.setSalt(userSalt);
            user.setLastLogin(lastLogin);

            
            // store User object in request
            request.setAttribute("user", user);
            
            //prints out error if any fields are empty
            if((fullName == null) || (fullName.equals(""))){
                request.setAttribute("errorMessage", "Fullname cannot be empty!");
                request.getRequestDispatcher("/signup.jsp").forward(request, response);
            }
            if((userName == null) || (userName.equals(""))){
                request.setAttribute("errorMessage", "Username cannot be empty!");
                request.getRequestDispatcher("/signup.jsp").forward(request, response);
            }
            if((email == null) || (email.equals(""))){
                request.setAttribute("errorMessage", "Email cannot be empty!");
                request.getRequestDispatcher("/signup.jsp").forward(request, response);
            }
            if((password == null) || (password.equals(""))){
                request.setAttribute("errorMessage", "Password cannot be empty!");
                request.getRequestDispatcher("/signup.jsp").forward(request, response);
            }
            if((birthday == null) || (birthday.equals(""))){
                request.setAttribute("errorMessage", "Birthday cannot be empty!");
                request.getRequestDispatcher("/signup.jsp").forward(request, response);
            }
            if((answer == null) || (answer.equals(""))){
                request.setAttribute("errorMessage", "Answer cannot be empty");
                request.getRequestDispatcher("/signup.jsp").forward(request, response);
            }
            
            //prints out error if passwords don't match
            if(!password.equals(confirmPassword)){
                request.setAttribute("errorMessage", "Password and Confirm Password are not equal!");  
                request.getRequestDispatcher("/signup.jsp").forward(request, response);                     
            }
            
            //checks to see if username and email 
            User checkuser = UserDB.search(user.getUserName());
            User checkemail = UserDB.search(user.getEmail());
            
            if((checkuser != null)){
                request.setAttribute("errorMessage", "Username is unavailable!");
                request.getRequestDispatcher("/signup.jsp").forward(request, response); 
            }
            else if(checkemail != null){
                request.setAttribute("errorMessage", "Email already has an account!");
                request.getRequestDispatcher("/signup.jsp").forward(request, response);
            }
            else{
                 //Insert In to Database
            UserDB.insert(user);

            //creates session
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            
            ArrayList<User> users = UserDB.searchALL(user.getEmail());
            session.setAttribute("users", users);

            // forward request to JSP
            url = "/home.jsp";
            
            getServletContext().getRequestDispatcher(url).forward(request, response);
            }
        }
        
        else if(action.equals("login")){
            // get parameters from the request
            String userEmail = request.getParameter("userEmail_check");
            String password = request.getParameter("password_check");
            String stay_in = request.getParameter("stay_in");
                        
            // get current session
            
            User user = UserDB.search(userEmail);
            
            try {
                password = UserDB.hashAndSaltPassword(user.getSalt(), password);
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(membershipServlet.class.getName()).log(Level.SEVERE, null, ex);
            }

            
            if(user == null){
                request.setAttribute("errorMessage", "login failed!");
                url = "/login.jsp";
            }
            else if((user.getEmail().equals(userEmail) || user.getUserName().equals(userEmail) ) && user.getPassword().equals(password)){
                HttpSession session = request.getSession();
                session.setAttribute("user", user);
                
                //set users and twits attributes here
                ArrayList<Twit> twits = TwitDB.searchAll(user);
                session.setAttribute("twits", twits);
                
                ArrayList<User> users = UserDB.searchALL(user.getEmail());
                session.setAttribute("users", users);
                        
                url = "/home.jsp";
            }
            else{
                request.setAttribute("errorMessage", "login failed!");
                url = "/login.jsp";
            }
            
            if(stay_in != null){
                //implement cookie stuff here
                Cookie c = new Cookie("user", user.getUserName());
                c.setMaxAge(60 * 60 * 24 * 365);
                c.setPath("/");
                response.addCookie(c);
            }
        
            getServletContext().getRequestDispatcher(url).forward(request, response);
        }
        
        else if(action.equals("update")){
            //To print out text from here
            response.setContentType("text/html");
            response.setCharacterEncoding("UTF-8");
            
            // get parameters from the request
            String fullName = request.getParameter("fullName");
            String password = request.getParameter("password");
            String confirmPassword = request.getParameter("confirmpassword");
            String birthday = request.getParameter("birthday");
            String questionNo = request.getParameter("questionNo");
            String answer = request.getParameter("answer");
            String profilePic = "Test";
            
            // store data in User object
            User user = UserDB.search(request.getParameter("userName"));
            user.setFullName(fullName);
            user.setBirthday(birthday);
            user.setQuestionNO(questionNo);
            user.setAnswer(answer);
            user.setProfilePic(profilePic);
            
            String hashAndSaltPass = "";
            
            try {
                hashAndSaltPass = UserDB.hashAndSaltPassword(user.getSalt(), password);
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(membershipServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            user.setPassword(hashAndSaltPass);
            
            // store User object in request
            request.setAttribute("user", user);
            
            //prints out error if any fields are empty
            if((fullName == null) || (fullName.equals(""))){
                request.setAttribute("errorMessage", "Fullname cannot be empty!");
                request.getRequestDispatcher("/signup.jsp").forward(request, response);
            }
            if((password == null) || (password.equals(""))){
                request.setAttribute("errorMessage", "Password cannot be empty!");
                request.getRequestDispatcher("/signup.jsp").forward(request, response);
            }
            if((birthday == null) || (birthday.equals(""))){
                request.setAttribute("errorMessage", "Birthday cannot be empty!");
                request.getRequestDispatcher("/signup.jsp").forward(request, response);
            }
            if((answer == null) || (answer.equals(""))){
                request.setAttribute("errorMessage", "Answer cannot be empty");
                request.getRequestDispatcher("/signup.jsp").forward(request, response);
            }
            
            //prints out error if passwords don't match
            if(!password.equals(confirmPassword)){
                request.setAttribute("errorMessage", "Password and Confirm Password are not equal!");  
                request.getRequestDispatcher("/signup.jsp").forward(request, response);                     
            }

            //Insert In to Database
            UserDB.update(user);

            //creates session
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            
            //update twits
            ArrayList<Twit> twits = TwitDB.searchAll(user);
            session.setAttribute("twits", twits);
            
            //updates users
            ArrayList<User> users = UserDB.searchALL(user.getEmail());
            session.setAttribute("users", users);

            // forward request to JSP
            url = "/signup.jsp";
            
            request.setAttribute("errorMessage", "Changes have been made");
            getServletContext().getRequestDispatcher(url).forward(request, response);
        }
        
        else if(action.equals("forgot")){
            String email = request.getParameter("email");
            String questionNo = request.getParameter("questionNo");
            String answer = request.getParameter("answer");
            
            String errmessage = "User does not exist or Information is incorrect";
            User user = UserDB.search(email);
            
            if(user == null || !user.getQuestionNo().equals(questionNo) || !user.getAnswer().equals(answer) ){
                request.setAttribute("errorMessage", errmessage);
                url = "/forgotpassword.jsp";
            }
            else{
                //Generate new password
                String newpassword = "";
                
                do{
                    newpassword = UserDB.randomString(8);
                }while(newpassword.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])"));
                
                //Set new password
                user.setPassword(newpassword);
                UserDB.update(user);
                //send email to user
                String from = "testing@gmail.com";
                String subject = "New Password";
                String body = "Dear " + user.getFullName() + ",\n\n" +
                    "Here is your new temporary password: " + newpassword;
                
                boolean isBodyHTML = false;
                
                try{
                    Email.sendMail(email, from, subject, body, isBodyHTML);
                }
                catch (MessagingException e){
                    String errorMessage = 
                    "ERROR: Unable to send email. " + 
                        "Check Tomcat logs for details.<br>" +
                    "NOTE: You may need to configure your system " + 
                        "as described in chapter 14.<br>" +
                    "ERROR MESSAGE: " + e.getMessage();
                    request.setAttribute("errorMessage", errorMessage);
                    
                    this.log( "Unable to send email. \n" +
                    "Here is the email you tried to send: \n" +
                    "=====================================\n" +
                    "TO: " + email + "\n" +
                    "FROM: " + from + "\n" +
                    "SUBJECT: " + subject + "\n" +
                    "\n" +
                    body + "\n\n");
                    
                    url = "/forgetpassword.jsp";
                    
                    request.getRequestDispatcher(url).forward(request, response);
                }
                errmessage = "Email has been sent, check your email for your new password";
                request.setAttribute("errorMessage", errmessage);
                url = "/login.jsp";

            }
            request.getRequestDispatcher(url).forward(request, response);
        }
        
        else if(action.equals("makeTwit")){
            // get parameters from the request
            String tweet = request.getParameter("twit");
            
            //get current session
            HttpSession session = request.getSession();
            
            //create user
            User user = null;
            user = (User) session.getAttribute("user");
            user = UserDB.search(user.getEmail());      //This is to get the ID
            
            //check if session is active
            if(user == null){
                request.setAttribute("errorMessage", "Unexpected error occured");
                url = "/login.jsp";
            }
            
            //for seperating strings
            String mentions = "";
            int index = 0;
            
            //while there are still @ symbols in twit
            while(tweet.indexOf('@', index) > 0){
                //if theres a space at the end of a mention, parse at the space
                if(tweet.indexOf(' ', tweet.indexOf('@', index)) > 0){
                    mentions += tweet.substring(tweet.indexOf('@', index), tweet.indexOf(' ', tweet.indexOf('@', index)));
                    index = tweet.indexOf(' ', tweet.indexOf('@', index));
                }
                //if there is no space it is the end of the twit, append the rest of the string
                else if(tweet.indexOf(' ', tweet.indexOf('@', index)) < 0){
                    mentions += tweet.substring(tweet.indexOf('@', index));
                    index = tweet.length();
                }
                //add a space between parses
                if(tweet.indexOf('@', index) > 0){
                    mentions += " ";
                }
            }
            
            String twitDate = "";
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            twitDate = dtf.format(now);
            
            //filling twit
            Twit twit = new Twit();
            twit.setUserName(user.getUserName());
            twit.setUserMention(mentions);
            twit.setTwit(tweet);
            twit.setTwitDate(twitDate);
            
            //putting it in database
            TwitDB.insert(twit);
            
            //same for hashtags
            String hashtags = "";
            index = 0;
            
            twit = TwitDB.search(twit);
            
            //while there are still # symbols in twit
            while(tweet.indexOf('#', index) > 0){
                //if theres a space at the end of a mention, parse at the space
                if(tweet.indexOf(' ', tweet.indexOf('#', index)) > 0){
                    hashtags = tweet.substring(tweet.indexOf('#', index), tweet.indexOf(' ', tweet.indexOf('#', index)));
                    index = tweet.indexOf(' ', tweet.indexOf('#', index));
                }
                //if there is no space it is the end of the twit, append the rest of the string
                else if(tweet.indexOf(' ', tweet.indexOf('#', index)) < 0){
                    hashtags = tweet.substring(tweet.indexOf('#', index));
                    index = tweet.length();
                }
                Hashtag hashtag = HashtagDB.search(hashtags);
                
                if(hashtag == null){
                    hashtag = new Hashtag();
                    hashtag.setHashtagText(hashtags);
                    hashtag.setHashtagCount(1);
                    
                    HashtagDB.insert(hashtag);
                    
                    hashtag = HashtagDB.search(hashtags);
                }
                else{
                    hashtag.setHashtagCount(hashtag.getHashtagCount() + 1);
                    
                    HashtagDB.update(hashtag);
                    
                    hashtag = HashtagDB.search(hashtags);
                }
                twitHashtag twithashtag = new twitHashtag();
                
                twithashtag.setTwitID(twit.getTwitID());
                twithashtag.setHashtagID(hashtag.getHashtagID());
                
                twitHashtagDB.insert(twithashtag);
            }
            
            //update twits
            ArrayList<Twit> twits = TwitDB.searchAll(user);
            session.setAttribute("twits", twits);
            
            url = "/home.jsp";
            getServletContext().getRequestDispatcher(url).forward(request, response);
        }
        
        else if(action.equals("deleteTwit")){
            // get parameters from the request
            String tweet = request.getParameter("twit");
            
            TwitDB.Delete(tweet);
            
            //get current session
            HttpSession session = request.getSession();
            
            //create user
            User user = null;
            user = (User) session.getAttribute("user");
            user = UserDB.search(user.getEmail());      //This is to get the ID
            
            //update twits
            ArrayList<Twit> twits = TwitDB.searchAll(user);
            session.setAttribute("twits", twits);
            
            url = "/home.jsp";
            getServletContext().getRequestDispatcher(url).forward(request, response);
        }
        
        else if(action.equals("followPerson"))
        {
            //get current session
            HttpSession session = request.getSession();
            
            //create user
            User user = null;
            user = (User) session.getAttribute("user");
            user = UserDB.search(user.getEmail());      //This is to get the ID
            
            int userID = user.getUserID(); 
            
            String followDate = "";
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            followDate = dtf.format(now);
            
            int following = 0;
            
            int followers = 0;
            
            Follow follow = new Follow();
            
            follow.setUserID(userID);
            follow.setFollowDate(followDate);
            follow.setFollowing(following);
            follow.setFollowers(followers);
            
            FollowDB.followUser(follow);
                    
            url = "/home.jsp";
            getServletContext().getRequestDispatcher(url).forward(request, response);
        }
        
        else if(action.equals("unfollowPerson"))
        {
            //get current session
            HttpSession session = request.getSession();
            
            User user = null;
            user = (User) session.getAttribute("user");
            user = UserDB.search(user.getEmail());      //This is to get the ID
            
            int userID = user.getUserID();             
            FollowDB.unfollowUser(userID);
            
            url = "/home.jsp";
            getServletContext().getRequestDispatcher(url).forward(request, response);
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
