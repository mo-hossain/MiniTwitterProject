/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;
import java.io.Serializable;
    
public class Hashtag implements Serializable {
    private int hashtagID;
    private String hashtagText;
    private int hashtagCount;
    
    public Hashtag(){
        hashtagText = "";
        hashtagCount = 0;
    }
    
    public int getHashtagID(){return this.hashtagID;}
    public String getHashtagText(){return this.hashtagText;}
    public int getHashtagCount(){return this.hashtagCount;}
    
    public void setHashtagID(int hashtagID){this.hashtagID = hashtagID;}
    public void setHashtagText(String hashtagText){this.hashtagText = hashtagText;}
    public void setHashtagCount(int hashtagCount){this.hashtagCount = hashtagCount;}
}
