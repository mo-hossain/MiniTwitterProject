//packages and imports
package business;
import java.io.Serializable;

//Twit javabean
public class Twit implements Serializable{
    private int TwitID;
    private String username;
    private String userMention;
    private String twit;
    private String twitDate;
    
    public Twit(){
        userMention = "";
        twit = "";
        twitDate = "";
    }
    
    //getters
    public int getTwitID(){return this.TwitID;}
    public String getUserName(){return this.username;}
    public String getUserMention(){return this.userMention;}
    public String getTwit(){return this.twit;}
    public String getTwitDate(){return this.twitDate;}
    
    //setters
    public void setTwitID(int TwitID){this.TwitID = TwitID;}
    public void setUserName(String username){this.username = username;}
    public void setUserMention(String userMention){this.userMention = userMention;}
    public void setTwit(String twit){this.twit = twit;}
    public void setTwitDate(String twitDate){this.twitDate = twitDate;}
}