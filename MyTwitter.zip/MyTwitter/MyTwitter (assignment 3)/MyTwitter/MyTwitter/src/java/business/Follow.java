/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.io.Serializable;

/**
 *
 * @author MomosMac
 */
public class Follow implements Serializable
{
    private int followedUserID;
    private int userID;
    private String followDate;
    private int following;
    private int followers;
    
    public Follow()
    {
        userID = 0;
        followDate = "";
        following = 0;
        followers = 0;
    }
    
    //getters
    public int getFollowedUserID(){return this.followedUserID;}
    public int getUserID(){return this.userID;}
    public String getFollowDate(){return this.followDate;}
    public int getFollowing(){return this.following;}
    public int getFollowers(){return this.followers;}
    
    //setters
    public void setFollowedUserID(int followedUserID){this.followedUserID = followedUserID;}
    public void setUserID(int userID){this.userID = userID;}
    public void setFollowDate(String followDate){this.followDate = followDate;}
    public void setFollowing(int following){this.following = following;}
    public void setFollowers(int followers){this.followers = followers;}
    
}
