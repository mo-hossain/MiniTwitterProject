/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;
import java.io.Serializable;

public class twitHashtag implements Serializable{
    private int twitHashtagID;
    private int hashtagID;
    private int twitID;
    
    public twitHashtag(){
        twitHashtagID = 0;
        hashtagID = 0;
        twitID = 0;
    }
    
    //getters
    public int getTwitHashtagID(){return this.twitHashtagID;}
    public int getHashtagID(){return this.hashtagID;}
    public int getTwitID(){return this.twitID;}
    
    //setters
    public void setTwitHashtagID(int twitHashtagID){this.twitHashtagID = twitHashtagID;}
    public void setHashtagID(int hashtagID){this.hashtagID = hashtagID;}
    public void setTwitID(int twitID){this.twitID = twitID;}
}
