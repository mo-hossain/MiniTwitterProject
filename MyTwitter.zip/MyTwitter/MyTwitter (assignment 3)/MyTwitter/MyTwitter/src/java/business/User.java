/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;
import java.io.Serializable;
/*
 * @javabean for User Entity
 */
public class User implements Serializable {
    //define attributes
    private int UserID;
    private String fullName;
    private String userName;
    private String email;
    private String password;
    private String birthday;
    private String questionNo;
    private String answer;
    private String profilePic;
    private String salt;
    private String lastLogin;
    
    public User()
    {
        fullName = "";
        userName = "";
        email = "";
        password = "";
        birthday = "";
        questionNo = "";
        answer = "";
        profilePic = "";
        salt = "";
        lastLogin = "";
    }
    
    //define set/get methods for all attributes.
    
//    public User(String fromString)
//    {
//        String[] data = fromString.replace("[", "").split(",");
//        this.setUserID(Integer.parseInt(data[0]));
//        this.setFullName(data[1]);
//        this.setUserName(data[2]);
//        this.setEmail(data[3]);
//        this.setPassword(data[4]);
//        this.setBirthday(data[5]);
//        this.setQuestionNO(data[6]);
//        this.setAnswer(data[7]);
//        this.setProfilePic(data[8]);
//    }
    
    //getters
    public int getUserID(){return this.UserID;}
    public String getFullName(){return this.fullName;}
    public String getUserName(){return this.userName;}
    public String getEmail(){return this.email;}
    public String getPassword(){return this.password;}
    public String getBirthday(){return this.birthday;}
    public String getQuestionNo(){return this.questionNo;}
    public String getAnswer(){return this.answer;}
    public String getProfilePic(){return this.profilePic;}
    public String getSalt(){return this.salt;}
    public String getLastLogin(){return this.lastLogin;}

    //setters
    public void setUserID(int UserID){this.UserID = UserID;}
    public void setFullName(String fullName){this.fullName = fullName;}
    public void setUserName(String userName){this.userName = userName;}
    public void setEmail(String email){this.email = email;}
    public void setPassword(String password){this.password = password;}
    public void setBirthday(String birthday){this.birthday = birthday;}
    public void setQuestionNO(String questionNo){this.questionNo = questionNo;}
    public void setAnswer(String answer){this.answer = answer;}
    public void setProfilePic(String profilePic){this.profilePic = profilePic;}
    public void setSalt(String salt){this.salt = salt;}
    public void setLastLogin(String lastLogin){this.lastLogin = lastLogin;}
    
    @Override
    public String toString()
    {
      StringBuilder sb = new StringBuilder();
      sb.append(String.format("[%s,%s]", this.getFullName(), this.getEmail()));
      return sb.toString();
    }
}
