/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataaccess;

import business.twitHashtag;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.http.HttpServlet;

/**
 *
 * @author test
 */
public class twitHashtagDB extends HttpServlet{
    public static boolean insert(twitHashtag twithashtag){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection(); 
        PreparedStatement ps = null;
        
        //SQL execute
          String preparedSQL = 
            "INSERT INTO twitHashtag (twitID, hashtagID) VALUES (?,?)";
        
        try{
            ps = connection.prepareStatement(preparedSQL);
            ps.setInt(1, twithashtag.getTwitID());
            ps.setInt(2, twithashtag.getHashtagID());
            ps.executeUpdate();
            
            return true;
       }
       catch(SQLException e){
           System.out.print(e);
           return false;
       }
       finally {
            //close connections
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static twitHashtag search(String hashtagID) {
        //connection
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        //SQL statements
        String SQLUserEmail = "SELECT * FROM twitHashtag WHERE hashtagID = ?";
        
        try{
            //execute prepared statement
            ps = connection.prepareStatement(SQLUserEmail);
            ps.setString(1, hashtagID);
            rs = ps.executeQuery();
            
            //new user
            twitHashtag twithashtag = null;
            
            if(rs.next()){
                //make user NOT null
                twithashtag = new twitHashtag();
                
                //set attributes 
                twithashtag.setTwitHashtagID(rs.getInt("twitHashtagID"));
                twithashtag.setHashtagID(rs.getInt("hashtagID"));
                twithashtag.setTwitID(rs.getInt("twitID"));
            }
            return twithashtag;
        }
        catch (SQLException e){
            System.out.println(e);
            return null;
        }
        finally{
            //close connections
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
}
