package dataaccess;

import business.Hashtag;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.http.HttpServlet;

public class HashtagDB extends HttpServlet{
    public static boolean insert(Hashtag hashtag){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection(); 
        PreparedStatement ps = null;
        
        //SQL execute
          String preparedSQL = 
            "INSERT INTO Hashtag (hashtagText, hashtagCount) VALUES (?,?)";
        
        try{
            ps = connection.prepareStatement(preparedSQL);
            ps.setString(1, hashtag.getHashtagText());
            ps.setInt(2, hashtag.getHashtagCount());
            ps.executeUpdate();
            
            return true;
       }
       catch(SQLException e){
           System.out.print(e);
           return false;
       }
       finally {
            //close connections
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static Hashtag search(String hashtagText) {
        //connection
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        //SQL statements
        String SQLUserEmail = "SELECT * FROM Hashtag WHERE hashtagText = ?";
        
        try{
            //execute prepared statement
            ps = connection.prepareStatement(SQLUserEmail);
            ps.setString(1, hashtagText);
            rs = ps.executeQuery();
            
            //new user
            Hashtag hashtag = null;
            
            if(rs.next()){
                //make user NOT null
                hashtag = new Hashtag();
                
                //set attributes 
                hashtag.setHashtagID(rs.getInt("hashtagID"));
                hashtag.setHashtagText(rs.getString("hashtagText"));
                hashtag.setHashtagCount(rs.getInt("hashtagCount"));
            }
            return hashtag;
        }
        catch (SQLException e){
            System.out.println(e);
            return null;
        }
        finally{
            //close connections
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static boolean update(Hashtag hashtag){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection(); 
        PreparedStatement ps = null;
        
        //SQL execute
          String preparedSQL = 
            "UPDATE hashtag SET hashtagCount = ? WHERE hashtagID = ?";
        
        try{
            ps = connection.prepareStatement(preparedSQL);
            ps.setInt(1, hashtag.getHashtagCount());
            ps.setInt(2, hashtag.getHashtagID());
            ps.executeUpdate();
            
            return true;
       }
       catch(SQLException e){
           System.out.print(e);
           return false;
       }
       finally {
            //close connections
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
}