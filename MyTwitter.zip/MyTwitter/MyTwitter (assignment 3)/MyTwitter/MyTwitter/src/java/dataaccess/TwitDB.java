package dataaccess;

import business.*;
import javax.servlet.http.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

public class TwitDB extends HttpServlet{
    public static boolean insert(Twit twit){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection(); 
        PreparedStatement ps = null;
        
        //SQL execute
          String preparedSQL = 
            "INSERT INTO twit (username, userMention, twit, twitDate)"
            + " VALUES (?,?,?,?)";
        
        try{
            ps = connection.prepareStatement(preparedSQL);
            ps.setString(1, twit.getUserName());
            ps.setString(2, twit.getUserMention());
            ps.setString(3, twit.getTwit());
            ps.setString(4, twit.getTwitDate());
            ps.executeUpdate();
            
            return true;
       }
       catch(SQLException e){
           System.out.print(e);
           return false;
       }
       finally {
            //close connections
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static Twit search(Twit twit) {
        //connection
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        //SQL statements
        String SQLUserEmail = "SELECT * FROM twit WHERE (username = ? "
                + "AND twitDate = ?)";
        
        try{
            //execute prepared statement
            ps = connection.prepareStatement(SQLUserEmail);
            ps.setString(1, twit.getUserName());
            ps.setString(2, twit.getTwitDate());
            rs = ps.executeQuery();
            
            //new user
            twit = null;
            
            if(rs.next()){
                //make user NOT null
                twit = new Twit();
                
                //set attributes 
                twit.setTwitID(rs.getInt("twitID"));
                twit.setUserName(rs.getString("username"));
                twit.setUserMention(rs.getString("userMention"));
                twit.setTwit(rs.getString("twit"));
                twit.setTwitDate(rs.getString("twitDate"));
            }
            return twit;
        }
        catch (SQLException e){
            System.out.println(e);
            return null;
        }
        finally{
            //close connections
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static ArrayList<Twit> searchAll(User user) {
        //connection
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        //SQL statements (by most recent)
        String SQLUserEmail = "SELECT * FROM twit WHERE username = ? OR userMention LIKE ? ORDER BY twitID DESC";
        
        try{
            //execute prepared statement
            ps = connection.prepareStatement(SQLUserEmail);
            ps.setString(1, user.getUserName());
            ps.setString(2,"%@"+user.getUserName()+"%");
            rs = ps.executeQuery();
            
            //new user
            ArrayList<Twit> twits = new ArrayList<>();
            
            
            while(rs.next()){
                Twit twit = new Twit();
                //set attributes 
                twit.setTwitID(rs.getInt("twitID"));
                twit.setUserName(rs.getString("username"));
                twit.setUserMention(rs.getString("userMention"));
                
                String temptwit = rs.getString("twit");
                int index = 0;
                String mention = "";
                
                while(temptwit.indexOf('@', index) > 0){
                    //if theres a space at the end of a mention, parse at the space
                    if(temptwit.indexOf(' ', temptwit.indexOf('@', index)) > 0){
                        mention = temptwit.substring(temptwit.indexOf('@', index), temptwit.indexOf(' ', temptwit.indexOf('@', index)));
                        temptwit = temptwit.replace(mention, "<a class='blueX'>" + mention + "</a>");
                        index = temptwit.indexOf(' ', temptwit.indexOf('@', index));
                    }
                    //if there is no space it is the end of the twit, append the rest of the string
                    else if(temptwit.indexOf(' ', temptwit.indexOf('@', index)) < 0){
                        mention = temptwit.substring(temptwit.indexOf('@', index));
                        temptwit = temptwit.replace(mention, "<a class='blueX'>" + mention + "</a>");
                        index = temptwit.length();
                    }
                }
                
                index = 0;
                mention = "";
                
                while(temptwit.indexOf('#', index) > 0){
                    //if theres a space at the end of a mention, parse at the space
                    if(temptwit.indexOf(' ', temptwit.indexOf('#', index)) > 0){
                        mention = temptwit.substring(temptwit.indexOf('#', index), temptwit.indexOf(' ', temptwit.indexOf('#', index)));
                        temptwit = temptwit.replace(mention, "<a href=\"membership?action=Hashtag\" class='blueX'>" + mention + "</a>");
                        index = temptwit.indexOf(' ', temptwit.indexOf('#', index));
                    }
                    //if there is no space it is the end of the twit, append the rest of the string
                    else if(temptwit.indexOf(' ', temptwit.indexOf('#', index)) < 0){
                        mention = temptwit.substring(temptwit.indexOf('#', index));
                        temptwit = temptwit.replace(mention, "<a href=\"membership?action=Hashtag\" class='blueX'>" + mention + "</a>");
                        index = temptwit.length();
                    }
                }
                
                twit.setTwit(temptwit);
                twit.setTwitDate(rs.getString("twitDate"));
                
                twits.add(twit);
            }
            
            return twits;
        }
        catch (SQLException e){
            System.out.println(e);
            return null;
        }
        finally{
            //close connections
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static void Delete(String TwitID) {
        //connection
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        //SQL statements (by most recent)
        String SQLUserEmail = "DELETE FROM twit WHERE twitID = ?";
        
        try{
            //execute prepared statement
            ps = connection.prepareStatement(SQLUserEmail);
            ps.setString(1, TwitID);
            ps.executeUpdate();
        }
        catch (SQLException e){
            System.out.println(e);
        }
        finally{
            //close connections
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
}
