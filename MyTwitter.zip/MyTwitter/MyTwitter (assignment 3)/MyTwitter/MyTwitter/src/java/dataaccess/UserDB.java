package dataaccess;

import business.User;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.servlet.http.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

public class UserDB extends HttpServlet{
    public static boolean insert(User user){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection(); 
        PreparedStatement ps = null;
        
        //SQL execute
          String preparedSQL = 
            "INSERT INTO user (fullname, username, emailAddress, password, "
                  + "birthdate, questionNo, answer, profilePicture, salt, lastLogin)"
            + " VALUES (?,?,?,?,?,?,?,?,?,?)";
        
        try{
            ps = connection.prepareStatement(preparedSQL);
            ps.setString(1, user.getFullName());
            ps.setString(2, user.getUserName());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getPassword());
            ps.setString(5, user.getBirthday());
            ps.setString(6, user.getQuestionNo());
            ps.setString(7, user.getAnswer());
            ps.setString(8, user.getProfilePic());
            ps.setString(9, user.getSalt());
            ps.setString(10, user.getLastLogin());
            ps.executeUpdate();
            
            return true;
       }
       catch(SQLException e){
           System.out.print(e);
           return false;
       }
       finally {
            //close connections
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static User search(String userEmail) {
        //connection
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        //SQL statements
        String SQLUserEmail = "SELECT * FROM user WHERE (emailAddress = ? "
                + "OR username = ?)";
        
        try{
            //execute prepared statement
            ps = connection.prepareStatement(SQLUserEmail);
            ps.setString(1, userEmail);
            ps.setString(2, userEmail);
            rs = ps.executeQuery();
            
            //new user
            User user = null;
            
            if(rs.next()){
                //make user NOT null
                user = new User();
                
                //set attributes 
                user.setUserID(rs.getInt("userID"));
                user.setFullName(rs.getString("fullname"));
                user.setUserName(rs.getString("username"));
                user.setEmail(rs.getString("emailAddress"));
                user.setPassword(rs.getString("password"));
                user.setBirthday(rs.getString("birthdate"));
                user.setQuestionNO(Integer.toString(rs.getInt("questionNo")));
                user.setAnswer(rs.getString("answer"));
                user.setProfilePic(rs.getString("profilePicture"));
                user.setSalt(rs.getString("salt"));
                user.setLastLogin(rs.getString("lastLogin"));
            }
            return user;
        }
        catch (SQLException e){
            System.out.println(e);
            return null;
        }
        finally{
            //close connections
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static ArrayList<User> searchALL(String userEmail) {
        //connection
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        //SQL statements
        String SQLUserEmail = "SELECT * FROM user WHERE NOT(emailAddress = ? "
                + "OR username = ?)";
        
        try{
            //execute prepared statement
            ps = connection.prepareStatement(SQLUserEmail);
            ps.setString(1, userEmail);
            ps.setString(2, userEmail);
            rs = ps.executeQuery();
            
            //new user
            User user = null;
            ArrayList<User> users = new ArrayList<>();
            
            while(rs.next()){
                //make user NOT null
                user = new User();
                
                //set attributes 
                user.setUserID(rs.getInt("userID"));
                user.setFullName(rs.getString("fullname"));
                user.setUserName(rs.getString("username"));
                user.setEmail(rs.getString("emailAddress"));
                user.setPassword(rs.getString("password"));
                user.setBirthday(rs.getString("birthdate"));
                user.setQuestionNO(Integer.toString(rs.getInt("questionNo")));
                user.setAnswer(rs.getString("answer"));
                user.setProfilePic(rs.getString("profilePicture"));
                user.setSalt(rs.getString("salt"));
                user.setLastLogin(rs.getString("lastLogin"));
                
                users.add(user);
            }
            return users;
        }
        catch (SQLException e){
            System.out.println(e);
            return null;
        }
        finally{
            //close connections
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static boolean update(User user){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection(); 
        PreparedStatement ps = null;
        
        //SQL execute
          String preparedSQL = 
            "UPDATE user SET fullname = ?, password = ?, birthdate = ?, "
                  + "questionNo = ?, answer = ?, salt = ?, lastLogin = ? WHERE emailAddress = ?";
        
        try{
            ps = connection.prepareStatement(preparedSQL);
            ps.setString(1, user.getFullName());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getBirthday());
            ps.setString(4, user.getQuestionNo());
            ps.setString(5, user.getAnswer());
            ps.setString(6, user.getSalt());
            ps.setString(7, user.getLastLogin());
            ps.setString(8, user.getEmail());
            ps.executeUpdate();
            
            return true;
       }
       catch(SQLException e){
           System.out.print(e);
           return false;
       }
       finally {
            //close connections
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static String randomString(int length){
        String CHAR = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789";
        String randomString = "";
        Random random = new Random();
        
        for(int i = 0; i < length;++i){
            int index = random.nextInt(CHAR.length());
             randomString += CHAR.charAt(index);
        }
        return randomString;
    }
    
    
    public static String hashPassword(String password) throws NoSuchAlgorithmException{
    
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.reset();
        md.update(password.getBytes());
        byte[] mdArray = md.digest();
        StringBuilder sb = new StringBuilder(mdArray.length * 2);
        for(byte b: mdArray){
            int v = b & 0xff;
            if(v < 16){sb.append('0');}
            
            sb.append(Integer.toHexString(v));    
        }
        return sb.toString();
    }
    
    public static String hashAndSaltPassword(String salt, String password) throws NoSuchAlgorithmException{       
        return hashPassword(password + salt);
    }
    
    
    
}