/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataaccess;

import business.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.http.HttpServlet;

/**
 *
 * @author MomosMac
 */
public class FollowDB extends HttpServlet
{
    public static boolean followUser(Follow Follow)
    {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection(); 
        PreparedStatement ps = null;
        
        //SQL statement to follow
          String SQLFollow = 
            "INSERT INTO Follow (userID, followDate, following, followers)"
            + " VALUES (?,?,?,?)";
          
          try{
            ps = connection.prepareStatement(SQLFollow);
            ps.setInt(1, Follow.getUserID());
            ps.setString(2, Follow.getFollowDate());
            ps.setInt(3, Follow.getFollowing());
            ps.setInt(4, Follow.getFollowers());
            ps.executeUpdate();
            
            return true;
       }
       catch(SQLException e){
           System.out.print(e);
           return false;
       }
       finally {
            //close connections
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
          
    
    }
    
    public static void unfollowUser(int userID)
    {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection(); 
        PreparedStatement ps = null;
        ResultSet rs = null;
    
        //SQL statement to unfollow
        String SQLUnfollow = "DELETE FROM Follow WHERE userID = ?";
        
        try{
            //execute prepared statement
            ps = connection.prepareStatement(SQLUnfollow);
            ps.setInt(1, userID);
            ps.executeUpdate();
        }
        catch (SQLException e){
            System.out.println(e);
        }
        finally{
            //close connections
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
        
    }

}
