-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema twitterdb
-- -----------------------------------------------------

DROP SCHEMA IF EXISTS `twitterdb`;

CREATE SCHEMA IF NOT EXISTS `twitterdb` DEFAULT CHARACTER SET utf8 ;
USE `twitterdb` ;

-- -----------------------------------------------------
-- Table `twitterdb`.`Follow`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `twitterdb`.`Follow` (
  `followedUserID` INT(11) NOT NULL,
  `userID` INT(11) NOT NULL,
  `followDate` VARCHAR(20) NOT NULL,
  `following` INT(50) NULL DEFAULT NULL,
  `followers` INT(50) NULL DEFAULT NULL,
  PRIMARY KEY (`followedUserID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `twitterdb`.`Hashtag`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `twitterdb`.`Hashtag` (
  `hashtagID` INT(11) NOT NULL AUTO_INCREMENT,
  `hashtagText` VARCHAR(280) NULL DEFAULT NULL,
  `hashtagCount` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`hashtagID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `twitterdb`.`twit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `twitterdb`.`twit` (
  `twitID` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(45) NOT NULL,
  `userMention` VARCHAR(280) NOT NULL,
  `twit` VARCHAR(280) NOT NULL,
  `twitDate` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`twitID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `twitterdb`.`twitHashtag`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `twitterdb`.`twitHashtag` (
  `twitHashtagID` INT(11) NOT NULL AUTO_INCREMENT,
  `hashtagID` INT(11) NOT NULL,
  `twitID` INT(11) NOT NULL,
  PRIMARY KEY (`twitHashtagID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `twitterdb`.`user`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `twitterdb`.`user` (
  `userID` INT(11) NOT NULL AUTO_INCREMENT,
  `fullname` VARCHAR(45) NOT NULL,
  `username` VARCHAR(45) NOT NULL,
  `emailAddress` VARCHAR(45) NOT NULL,
  `password` VARCHAR(256) NOT NULL,
  `birthdate` VARCHAR(10) NOT NULL,
  `questionNo` INT(11) NOT NULL,
  `answer` VARCHAR(45) NOT NULL,
  `profilePicture` VARCHAR(10) NULL DEFAULT NULL,
  `salt` VARCHAR(8) NULL DEFAULT NULL,
  `lastLogin` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`userID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- -----------------------------------------------------
-- View `twitterdb`.`topten`
-- -----------------------------------------------------
CREATE VIEW `topten` AS
    SELECT 
        `hashtag`.`hashtagID` AS `hashtagID`,
        `hashtag`.`hashtagText` AS `hashtagText`,
        `hashtag`.`hashtagCount` AS `hashtagCount`
    FROM
        `hashtag`
    ORDER BY `hashtag`.`hashtagCount` DESC
    LIMIT 10;
    
-- -----------------------------------------------------
-- View `twitterdb`.`topten`
-- -----------------------------------------------------
CREATE VIEW `SelectedHashtag` AS
	SELECT
		`twit`.`twitID` AS `twitID`,
		`twit`.`username` AS `username`,
        `twit`.`userMention` AS `userMention`, 
		`twit`.`twit` AS `twit`,
        `twit`.`twitDate` AS `twitDate`,
        `hashtag`.`hashtagText` AS `hashtagText`
FROM `twithashtag` 
INNER JOIN `hashtag` 
	ON `hashtag`.`hashtagID` = `twithashtag`.`hashtagID`
INNER JOIN `twit` 
	ON `twit`.`twitID`= `twithashtag`.`twitID`